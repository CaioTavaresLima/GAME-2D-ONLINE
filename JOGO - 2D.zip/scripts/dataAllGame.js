   let skinsOrange = [{
    id : 0,
    preco : 100,
    url : './assets/person/orange_boy.gif'
   },{
   id: 1,
     preco: 120,
     url: './assets/person/orange_men.gif'
   },{
   id: 2,
     preco: 140,
     url: './assets/person/orange_male.gif'
   },{
   id: 3,
     preco: 160,
     url: './assets/person/orange_female.gif'
    }]

   let skinsRuby = [{
      id: 0,
      preco: 300,
      url: './assets/person/ruby_boy.gif'
    }, {
      id: 1,
      preco: 350,
      url: './assets/person/ruby_girl.gif'
    }, {
      id: 2,
      preco: 400,
      url: './assets/person/ruby_men.gif'
    }, {
      id: 3,
      preco: 450,
      url: './assets/person/ruby_woman.gif'
    },{
      id: 4,
      preco : 500,
      url: './assets/person/ruby_zombie.gif'
    }]
  
   let skinsBlack = [{
      id: 0,
      preco: 800,
      url: './assets/person/black_bot.gif'
    }, {
      id: 1,
      preco: 880,
      url: './assets/person/black_zombie.gif'
    }]






////////////////////////////////////////////////////////////////////////////////

   // SAVE GAME DATA //

    let skinsOrangeBuy = []
    let skinsRubyBuy = []
    let skinsBlackBuy = []
    
    

  function saveSkinsOrangeBuy(id){
      skinsOrangeBuy.push(skinsOrange[id])
      skinsOrangeBuyJson = JSON.stringify(skinsOrangeBuy)
      window.localStorage.setItem("orangeBuy", skinsOrangeBuyJson)
      console.log('COMPRA FEITA TIER ORANGE')
      console.log(JSON.parse(localStorage.getItem("orangeBuy")))
  }
  function saveSkinsRubyBuy(id) {
      skinsRubyBuy.push(skinsRuby[id])
      skinsRubyBuyJson = JSON.stringify(skinsRubyBuy)
      window.localStorage.setItem("rubyBuy", skinsRubyBuyJson)
      console.log('COMPRA FEITA TIRE RUBY')
      console.log(JSON.parse(localStorage.getItem("rubyBuy")))
  }
 function saveSkinsBlackBuy(id) {
      skinsBlackBuy.push(skinsBlack[id])
      skinsBlackBuyJson = JSON.stringify(skinsBlackBuy)
      window.localStorage.setItem("blackBuy", skinsBlackBuyJson)
      console.log('COMPRA FEITA TIRE BLACK')
      console.log(JSON.parse(localStorage.getItem("blackBuy")))
  }
 
 
 
 
 
    let skinOrangeActive = JSON.parse(localStorage.getItem("orangeBuy"))
    let skinRubyActive = JSON.parse(localStorage.getItem("rubyBuy"))
    let skinBlackActive = JSON.parse(localStorage.getItem("blackBuy"))

    console.log(skinOrangeActive)
    console.log(skinRubyActive)
    console.log(skinBlackActive)
   










 