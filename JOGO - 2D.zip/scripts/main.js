
    
     let cvs;
     let ctx;
     let dificuldade = 5
     
    
    game_chao = {
      x : 0,
      y : 140,
      altura : 10,
      cor : '#333',
      chao_render : function(){
        ctx.beginPath();
        ctx.fillStyle = this.cor
        ctx.fillRect(this.x, this.y  , 300, this.altura)
        ctx.closePath();
      }
    }
    
    game_player = {
      x : 50,
      y : 0, 
      altura : 10,
      largura : 10,
      cor : '#999',
      url : './assets/person-static/player_stand.png',
      gravidade : 1,
      velocidade_queda : 0,
      forca_do_pulo : 10,
      render_player : function(){

        ctx.beginPath()
        ctx.drawImage(this.url,this.x , this.y, this.largura, this.altura)
        ctx.closePath()
      },
      frames_player : function(){
        
        
        
        
        
        this.velocidade_queda += this.gravidade
        this.y += this.velocidade_queda
        if(this.y > game_chao.y - this.altura){
          this.y = game_chao.y  - this.altura 
        }
        
      },
      pular_player : function(){
        
         this.velocidade_queda = -this.forca_do_pulo
        
      }
      }
    
    
    game_obs = {
      _obj : [],
      tempo_insere : 0,
      insere : function(){
        this._obj.push({
          x : 300,
          y : 140,
          altura : 2 * Math.floor(Math.random() * 10),
          largura : 2 * Math.floor(Math.random() * 10)
        })
        this.tempo_insere = 30 + Math.floor(Math.random() * 5)
      },
      render_obs : function(){
        obj = this._obj
        for(i in obj){
          
           ctx.beginPath()
           ctx.fillStyle = '#555'
           ctx.fillRect(obj[i].x - obj[i].largura, obj[i].y - obj[i].altura , obj[i].largura, obj[i].altura) 
           ctx.closePath()
        }
      },
      frames_obs : function(){
        if(this.tempo_insere == 0){
          this.insere()
        } else {
          this.tempo_insere--;
        }
        obj = this._obj
        for(i in obj){
          obj[i].x -= dificuldade
          if(obj[i].x < 0){
            obj.splice(i, 1)
          }
        }
      }
    }
    
    function playerPulo(){
      game_player.pular_player();
    }
    
    function gameRender(){
      
      ctx.beginPath()
      ctx.fillStyle = '#50beff'
      ctx.fillRect(0,0, 300, 150)
      ctx.closePath()
      
      
      
      game_chao.chao_render();
      game_player.render_player();
      game_obs.render_obs();
     
    }
    
    function gameFrames(){
      game_player.frames_player()
      gameRender()
      game_obs.frames_obs()
      window.requestAnimationFrame(gameFrames);
    }
    
    
                                      
    window.addEventListener('load', function(){     
         cvs = document.getElementById('canvas');
         ctx = cvs.getContext('2d');
         gameFrames();
         gameRender();
});

 

    