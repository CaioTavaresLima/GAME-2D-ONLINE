
  function actionPage(action){
    let addPlayerPage = document.querySelector('.add-player')
    switch (action) {
      case 0:
       
        break;
      case 1:
        addPlayerPage.style.marginLeft = '25%'
        addPlayerPage.style.transition = '.4s'
        break;
      case 2:
        addPlayerPage.style.marginLeft = '-110%'
        addPlayerPage.style.transition = '.4s'
        break;
    }
  }