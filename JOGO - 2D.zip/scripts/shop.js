


   function setSkin(){
     let orangeSection = document.querySelector('.orange-items');
     let rubySection = document.querySelector('.ruby-items')
     let blackSection = document.querySelector('.black-items')
     for(i in skinsOrange){
     orangeSection.innerHTML += '<div>' + '<img src=' + skinsOrange[i].url + '><nav><input type="button" value="'+ skinsOrange[i].preco +'"><input type="button" value="Comprar" onclick="buySkin('+ 0 +','+ skinsOrange[i].id  +')"></div>'
     console.log('ORANGE --- ID : ' + skinsOrange[i].id + ' | DIRETÓRIO : ' + skinsOrange[i].url);      
     }
     for (i in skinsRuby) {
       rubySection.innerHTML += '<div>' + '<img src=' + skinsRuby[i].url + '><nav><input type="button" value="'+ skinsRuby[i].preco +'"><input type="button" value="Comprar" onclick="buySkin('+ 1 +','+ skinsRuby[i].id  +')"></div>'
       console.log('RUBY --- ID : ' + skinsRuby[i].id + ' | DIRETÓRIO : ' + skinsRuby[i].url);
     }
     for (i in skinsBlack) {
       blackSection.innerHTML += '<div>' + '<img src=' + skinsBlack[i].url + '><nav><input type="button" value="'+ skinsBlack[i].preco +'"><input type="button" value="Comprar" onclick="buySkin('+ 2 +','+ skinsBlack[i].id  +')"></div>'
       console.log('BLACK --- ID : ' + skinsBlack[i].id + ' | DIRETÓRIO : ' + skinsBlack[i].url);
     }
   }
   
   function buySkin(tier, id){
     switch(tier){
       case 0 :
          saveSkinsOrangeBuy(id)
          console.log('TIER ORANGE - ID :' + id)
         break;
       case 1:
         saveSkinsRubyBuy(id)
         console.log('TIER RUBY - ID :' + id)
       break;
       case 2:
         saveSkinsBlackBuy(id)
         console.log('TIER BLACK - ID :' + id)
       break;
     }
   }
  
   window.addEventListener('load', function(){
     setSkin()
   });